<?php
    return[
        'backend_date_format' => 'Y-m-d',
        'frontend_date_format' => 'd/m/Y',
        'js_date_format' => "dd/mm/yy",
    ];
