<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PrescriptionInfo extends Model
{
    protected $guarded = [];
}
