<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DoctorSpecialist extends Model
{
    protected $guarded = [];

}
